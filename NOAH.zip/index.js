const express = require("express")
require("pug")
const app = express()
app.listen(3456, ()=>{console.log("port: 3456")})
const {getData, saveData, getUsers} = require("./db")
const fs = require("fs")
const session = require("express-session")
const users = require("./users.json")





/* app.use(session({
	secret: "sf",
	resave: false,
	saveUninitialized: true
})) */

app.use(session({
  secret: 'keyboard cat',
  resave: false,
  saveUninitialized: true,
  cookie: {
      httpOnly: true,
      secure: false,
    }
  }
))

function auth(req, res, next){
	if(!req.session.user){
		res.locals.auth = false;
		return res.render("index",{error:"Not logged in..."})
	}
	res.locals.auth = true;
	// Nedanstående variabel blir åtkomlig för pug som variabel user
	res.locals.user = req.session.user
	next()
}

app.set("view engine", "pug")

app.use(express.urlencoded({extended:true}))



app.get("/",auth, (req, res)=>{
	console.log("INDEX",req.session)
    res.render("index",{title:"HOME", name:"Noah"})

})

app.get("/session", (req, res) => {
	console.log("SESSION", req.session);
res.send(req.session);
})


app.get("/products", auth, (req, res) => {
	const products = getData()

	res.render("products",{products: products})
})

app.get("/products/create/:name/:price", (req, res) => {
    const prod = req.params
    prod.id = Date.now()
    const products = getData()
    products.push(prod)
    saveData(products)


    res.redirect("/products")


})
app.get("/products/delete/:id", (req, res)=>{
    const id = req.params.id
    const products = getData()

    const filteredProducts = products.filter(p=>p.id !=id)
    let mes= id + "_deleted"
    
    if(products.length == filteredProducts.length){
        mes = "Nothing_Deleted"
    }


    saveData(filteredProducts)
    res.redirect("/products?"+mes)
   
})




app.post("/login", (req, res) => {
	const { email, password } = req.body
	const users = getUsers();
	const user = users.find(u => u.email == email && u.password == password)


	if(!user){
			console.log("FEL INLOGGNINHG");
		return res.render("index", { 
			error: "Fel email eller lösenord"
		
		})
	}



	req.session.user = user
	req.session.auth  = true;
	res.locals.user = req.session.user
	res.locals.auth = true;

	res.redirect("/");
})